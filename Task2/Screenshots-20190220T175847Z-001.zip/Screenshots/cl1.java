package p1;

import java.util.Scanner;

public class cl1 {
	public static void main(String[] arg) {
		 Scanner in=new Scanner(System.in);
		 System.out.print("������� ����������� �������:");
		 int len=in.nextInt();
		 int[] mass=new int[len];
		 int i;
		 for(i=0;i<len;i++)
		 {
		     mass[i]=(int)(Math.random()*100);
		     System.out.print(mass[i]+" ");
		 }
		 int d=len/2;
		 while(d>=1)
		 {
			 int j;
			 for(j=0;len/d;j++)
			 {
				 ;
				 
			 }
			 d=d/2;
		 }
		
		
	}

}
